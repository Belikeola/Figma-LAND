jQuery(document).ready(function($) {


    $("#settings-button").click(function() {
        $("#theme-settings").toggleClass("active");
        $(this).toggleClass("active");

    });



    $(".gradient1").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#e84040; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#e84040;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #e84040;}#services i.fa, #testimonials {background:#e84040;} '
        }).appendTo('head');


    });

    $(".gradient2").click(function() {

        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#1D4079; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#1D4079;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #1D4079;}#services i.fa, #testimonials {background:#1D4079;}'
        }).appendTo('head');

    });

    $(".gradient3").click(function() {

        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#2E7D32; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#2E7D32;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #2E7D32;}#services i.fa, #testimonials {background:#2E7D32;}'
        }).appendTo('head');

    });

    $(".gradient4").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#1abc9c; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#1abc9c;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #1abc9c;}#services i.fa, #testimonials {background:#1abc9c;} '
        }).appendTo('head');


    });


    $(".gradient5").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#607D8B; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#607D8B;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #607D8B;}#services i.fa, #testimonials {background:#607D8B;} '
        }).appendTo('head');


    });




    $(".gradient6").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#f39c12; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#f39c12;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #f39c12;}#services i.fa, #testimonials {background:#f39c12;} '
        }).appendTo('head');


    });

 $(".gradient7").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#512DA8; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#512DA8;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #512DA8;}#services i.fa, #testimonials {background:#512DA8;} '
        }).appendTo('head');


    });




    $(".gradient8").click(function() {



        $('<style />', {
            text: '.navbar-default .navbar-nav > .active > a,.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {border-bottom-color:#737373; }section h2.section-heading, .text-muted-role, a, .navbar-default .nav li a:hover, .navbar-default .nav li a:focus {color:#737373;}.btn-xl, ul.social-buttons li a, ul.filter li a, .pricing .border, .pricing a.btn-send, .scroll-up a, .navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle, .scroll-up a:hover, .scroll-up a:active, .pricing-top-box {background-color: #737373;}#services i.fa, #testimonials {background:#737373;} '
        }).appendTo('head');


    });


});
