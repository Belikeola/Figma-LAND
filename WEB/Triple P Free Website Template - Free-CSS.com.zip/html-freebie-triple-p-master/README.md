# html-freebie-triple-p
Website Template Name: Triple P (Pixel Perfect Portfolio)

Description: Pixel Perfect Portfolio is a modern and elegant One-Page HTML template. The template is built using technologies such as Bootstrap 3+, jQuery, SASS, Gulp &amp; Bower. It's perfectly suitable for freelancers, designers &amp; all kind of artists who want to show off their work.  

Version: 1
Author: Pixel Perfect Team
Author URI: http://pixelperfect.mk/
Keywords: HTML, CSS, Bootstrap, Responsive, Javascript, jQuery, Parallax, Portfolio, CV, Resume